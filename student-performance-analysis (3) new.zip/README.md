
# Student Study & Performance Analysis

## 1. Project Overview
This project analyses student study hours, academic marks,
and attendance using Python.

## 2. Dataset
The dataset contains 20 student records.

Columns:
- Student_ID
- Study_Hours
- Maths
- Physics
- Chemistry
- Attendance

## 3. Tools Used
- Python
- Pandas
- Matplotlib
- Seaborn
- Google Colab

## 4. Data Analysis
- Mean
- Median
- Mode
- Maximum and Minimum
- Subject-wise Average Marks
- Student Performance Categories

## 5. Visualizations
Four charts were created:
1. Bar Chart
2. Line Chart
3. Pie Chart
4. Histogram

## 6. Conclusion
This project demonstrates how Python can be used
to analyse student academic performance and visualize
the results using different charts.

## Author
Guruprasath
